// FEAT-010 mutation run. Applies each mutation in tests/feat-010/mutations.mjs
// one at a time and re-runs the whole SQL suite against it.
//
// The bar: every mutation must make at least one test fail. A zero is a
// defective test, not a harmless mutation.
import { spawn } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { mutations } from '../tests/feat-010/mutations.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const evidence = new URL('../docs/feat-010/evidence/', import.meta.url);
await mkdir(evidence, { recursive: true });

const only = process.argv.slice(2);
const names = Object.keys(mutations).filter(n => !only.length || only.includes(n));
const rows = [];

for (const name of names) {
  let output = '';
  await new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ['--test', 'tests/feat-010/database.test.mjs'], {
      cwd: root, env: { ...process.env, FEAT010_MUTATION: name, NO_COLOR: '1' },
    });
    child.stdout.on('data', x => output += x);
    child.stderr.on('data', x => output += x);
    child.on('error', reject);
    child.on('close', resolve);
  });
  const failed = Number(output.match(/^# fail (\d+)$/m)?.[1] ?? NaN);
  const total = Number(output.match(/^# tests (\d+)$/m)?.[1] ?? NaN);
  const failing = [...output.matchAll(/^not ok \d+ - (.+)$/gm)].map(m => m[1]);

  // A mutation whose snippet no longer matches throws inside the fixture, which
  // fails every test — and a naive runner reads that as an emphatic catch. It
  // has happened three times on this feature (M2/M3/M4/M10 after RC2's edits,
  // M5/M6 after RC3's). A mutation that did not apply proves nothing, so it is
  // its own verdict.
  const broken = /mutation (?:phải khớp|không tìm thấy|tên)/.test(output);
  // A mutation that fails *every* test has almost certainly broken the schema
  // rather than broken one rule — the migration did not install, so nothing was
  // proved. That happened to M46 on its first draft and read as a 54-test
  // catch. Same principle as `broken` above: a verdict that cannot distinguish
  // "the guard works" from "nothing ran" is not a verdict.
  const wipeout = !broken && Number.isFinite(total) && total > 0 && failed === total;
  rows.push({ name, what: mutations[name].what, failed, total, failing, broken, wipeout });
  const verdict = broken ? '*** MUTATION KHÔNG ÁP DỤNG ĐƯỢC ***'
    : wipeout ? '*** TOÀN BỘ SUITE FAIL — nghi mutation làm hỏng migration ***'
    : failed > 0 ? 'CAUGHT' : '*** NOT CAUGHT ***';
  console.log(`${name.padEnd(4)} ${String(failed).padStart(2)} failing  ${verdict}  ${mutations[name].what}`);
  if (broken) console.log('   ' + (output.match(/mutation (?:phải khớp|không tìm thấy)[^\n]*/)?.[0] ?? ''));
  else if (!Number.isFinite(failed) || failed === 0) console.log(output.slice(-4000));
}

await writeFile(new URL('mutations.json', evidence), JSON.stringify(rows, null, 2));
const escaped = rows.filter(r => r.broken || r.wipeout || !(r.failed > 0));
console.log(`\n${rows.length - escaped.length}/${rows.length} mutations caught.`);
if (escaped.length) {
  const notCaught = escaped.filter(r => !r.broken && !r.wipeout).map(r => r.name);
  const notApplied = escaped.filter(r => r.broken).map(r => r.name);
  if (notCaught.length) console.log('Không bắt được: ' + notCaught.join(', '));
  if (notApplied.length) console.log('Không áp dụng được (mutation hỏng, không phải test tốt): ' + notApplied.join(', '));
  const wiped = escaped.filter(r => r.wipeout).map(r => r.name);
  if (wiped.length) console.log('Làm fail toàn bộ suite (nhiều khả năng hỏng migration, không chứng minh gì): ' + wiped.join(', '));
  process.exitCode = 1;
}
