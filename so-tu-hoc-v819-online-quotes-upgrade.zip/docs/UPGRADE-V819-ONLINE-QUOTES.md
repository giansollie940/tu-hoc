# V8.1.9 — Danh ngôn trực tuyến cho Cú Thông Thái

Nguồn:
https://www.tudiendanhngon.vn/danhngon/ds/strcats/180

Nguồn hiện có 4 trang trong chuyên mục “Học hỏi”.

## Cơ chế

1. App cần một câu danh ngôn.
2. Frontend gọi Edge Function `quote-feed`.
3. Edge Function đọc 4 trang nguồn ở server.
4. Parser lấy các liên kết chi tiết danh ngôn và tác giả.
5. Kho kết quả được cache trong bộ nhớ Edge Function tối đa 60 phút.
6. Trình duyệt lưu các ID đã nói trong `localStorage`.
7. Mỗi request gửi danh sách ID đã dùng.
8. Function chỉ chọn câu chưa dùng.
9. Khi đã dùng hết toàn bộ kho, bắt đầu một vòng mới.
10. Nếu website nguồn hoặc Edge Function tạm lỗi, app dùng kho danh ngôn tĩnh hiện có làm dự phòng.

## Không lặp

Khóa localStorage:

`wiseOwlSeenQuotes:<USER_ID>`

Lịch sử được giữ qua F5 và đóng/mở trình duyệt trên cùng thiết bị.

Khi hết kho, function trả `cycleReset=true`; app xóa vòng cũ và bắt đầu lại.

## Quyền riêng tư

`quote-feed` không cần đọc dữ liệu học sinh, không dùng service_role và không gửi nội dung đăng ký học tập ra nguồn danh ngôn.

## Triển khai

### Supabase
Tạo Edge Function mới:

`quote-feed`

Paste:
`supabase/functions/quote-feed/index.ts`

Với frontend dùng publishable key, đặt:
`Verify JWT = OFF`

Function chỉ đọc website danh ngôn công khai và không có quyền database.

### GitHub
Thay:
- `app.js`
- `supabase-service.js`

Không cần SQL.

## Kiểm tra

1. Đăng nhập.
2. Bấm Cú nhiều lần.
3. Khoảng mỗi lần yêu cầu danh ngôn, câu sẽ khác các câu đã nói trước đó.
4. F5 và thử tiếp: lịch sử không lặp vẫn được giữ.
5. Trong DevTools/localStorage sẽ có `wiseOwlSeenQuotes:<USER_ID>`.
6. Nếu nguồn web tạm lỗi, Cú vẫn nói bằng kho dự phòng.
